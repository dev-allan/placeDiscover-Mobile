const UserSchema = {

    name: "User",

    properties: {
      _id: "objectId",
      lastname: "string",
      firstname: "string",
      email: "string", 
      password: "string",
      avatar_url: "string?",
      last_position: "string?",
      vehicle: { "type": "string", "default": 'walk' }
    },

    primaryKey: "_id",

  };

export default UserSchema;