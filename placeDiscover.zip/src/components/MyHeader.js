import React, { useState } from 'react';
import { StyleSheet, View, Text, Image, TouchableOpacity, } from 'react-native';


const MyHeader = ( props ) => {

    const { route, navigation } = props
    const { name } = route

    console.log('myheader', props)

    return (
        
        <View style={[styles.container, { height: 70, flexDirection: 'row', }]}>
            
            <TouchableOpacity 
                style={{ flex: 1, justifyContent: 'center', alignItems: 'center'}}
                onPress={ () => navigation.goBack()}
            >
                <Image
                    style={{ height: 25, width: 25, resizeMode: 'contain'}}
                    source={require('../img/icon/arrowBackViolet.png')}
                />
            </TouchableOpacity>

            <View style={{ flex: 4, justifyContent: 'center', alignItems: 'center'}}>
                <Text numberOfLines={1} style={{ color: '#a018db', fontSize: 16, textAlign: 'center', }}>{name}</Text>
            </View>

            <View style={{ flex: 1,}}>
                
            </View>

        </View>

    )
}


const styles = StyleSheet.create({

    container: { 
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#000',
        borderBottomColor: '#a018db',
        borderBottomWidth: 1,
    },

});


export default MyHeader;
