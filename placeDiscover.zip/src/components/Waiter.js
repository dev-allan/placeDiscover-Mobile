import React, { useContext } from 'react';
import { StyleSheet, StatusBar, View, Text, Image, ActivityIndicator } from 'react-native';


const Waiter = ( ) => {


    return (
        
        <View style={styles.container}>

            <ActivityIndicator size="large" color="white" style={{ marginVertical: 10 }} />
            <Text style={{ color: '#ccc', fontSize: 18, textAlign: 'center',  }}>Merci de patienter..</Text>

        </View>

    )
}


const styles = StyleSheet.create({

    container: { 
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },

});


export default Waiter;
