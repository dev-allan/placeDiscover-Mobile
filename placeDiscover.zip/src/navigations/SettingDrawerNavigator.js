import React, { useEffect, useState } from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { StyleSheet, StatusBar, ScrollView, View, DrawerItemList, Text, Image, Pressable } from 'react-native';


import VideoScreen from '../screens/VideoScreen';


const Drawer = createDrawerNavigator();


const SettingDrawerNavigator = ( props ) => {


    return (

        <Drawer.Navigator 
            initialRouteName="Video"
            drawerStyle={{ }}
            drawerContent={(props) => {

                return (

                    <LinearGradient {...props} start={{x: 0, y: 0}} end={{x: 0, y: 1}} colors={['#084A65', '#000']} style={styles.container}>
                    
                        <Text style={{ width: '100%', fontSize: 20, fontWeight: 'bold', color: '#ddd', marginVertical: 20, textAlign: 'left'}}>Filtres</Text>

                        <Picker
                            style={{ width: '100%', color: '#000'}}
                            selectedValue={category}
                            onValueChange={(itemValue, itemIndex) => {updateMovieOptions(itemIndex); console.log(itemIndex)}}
                        >
                            <Picker.Item label="catégories.." value="" />
                            { genre.map((element, index) => <Picker.Item label={element.name} value={element.id} key={index} />)}
                        </Picker>

                    </LinearGradient>

                );
            }}
        >
            <Drawer.Screen name="Video" >
                {props => <VideoScreen {...props} movieData={movieData} />}
            </Drawer.Screen>
        </Drawer.Navigator>

    );
}

const styles = StyleSheet.create({

    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    
});


export default SettingDrawerNavigator;