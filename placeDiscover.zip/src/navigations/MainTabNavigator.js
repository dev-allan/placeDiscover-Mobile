import * as React from 'react'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'

// navigations and screens //
// import MyConnexionTab from '../components/MyConnexionTab'
// import MyMainTab from '../components/MyMainTab'
// import HomeScreen from '../screens/HomeScreen'
// import ConnectionStackNavigator from './MainStackNavigator'


const Tab = createBottomTabNavigator();


const MainTabNavigator = ( ) => {
    

    return (

        <Tab.Navigator
        initialRouteName='Home'
            tabBarOptions={
                { 
                activeBackgroundColor: '#111',
                inactiveBackgroundColor: '#000',
                activeTintColor: '#a018db',
                inactiveTintColor: '#888',
                labelPosition: 'below-icon', 
                labelStyle: {fontSize: 12},
                tabStyle: { borderTopColor: '#a018db', borderTopWidth: 1},
                keyboardHidesTabBar: true,
                }
            }  

            // condition à faire pour changer de tab une fois connectée //
            tabBar={(props) => <MyConnexionTab {...props} />}
             // condition à faire pour changer de tab une fois connectée //
        >

            <Tab.Screen 
                name="Home" 
                options={{ 
                    title: 'Accueil',
                }}
            >
                {props => <HomeScreen {...props} />}
            </Tab.Screen>

            <Tab.Screen 
                name="ConnectionStack" 
                // options={{ 
                //     title: 'Inscription',
                // }}
            >
                {props => <ConnectionStackNavigator {...props} />}
            </Tab.Screen>

            {/* <Tab.Screen 
                name="ConnectionStack"
                options={{ 
                    title: 'Connexion',
                }}  
            >
                {props => <LogerScreen {...props} />}
            </Tab.Screen> */}
            
        </Tab.Navigator>

    );
};

export default MainTabNavigator
