import { NavigationContainer } from '@react-navigation/native';
import React from 'react';
import { StyleSheet, SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList } from 'react-native';


const HomeScreen = ( props ) => {

    const { navigation } = props


    return (

        <View style={styles.container} >

            <View style={{ flex: 8, justifyContent: 'space-around', alignItems: 'center',}}>

                <Text style={{ color: '#a018db'}}>HomeScreen</Text>

                <TouchableOpacity
                    onPress={() => navigation.navigate( 'Localizer' )}
                >
                    <Text style={{ fontSize: 22, color: '#fff', backgroundColor: '#a018db', paddingVertical: 5, paddingHorizontal: 15, borderRadius: 10 }}>Que faire dans ma ville ..?</Text>
                </TouchableOpacity>

                <View style={{ backgroundColor: '#fff1', marginHorizontal: 50, padding: 10, }}>
                    <Text style={{ color: '#888', marginBottom: 10}}>City Travel vous aide à trouver des activités autour de vous..</Text>
                    <Text style={{ color: '#888'}}>Restaurant</Text>
                    <Text style={{ color: '#888'}}>Cinéma</Text>
                    <Text style={{ color: '#888'}}>Musée</Text>
                    <Text style={{ color: '#888'}}>Parc</Text>
                    <Text style={{ color: '#888'}}>...</Text>

                </View>

            </View>

            <View style={{ flex: 1, flexDirection: 'row', width: '100%', }}>

                <TouchableOpacity
                    style={{ flex: 1, justifyContent: 'center', alignItems: 'center', }}
                    onPress={() => navigation.navigate( 'Register' )}
                >
                    <Text style={{ color: '#a018db', backgroundColor: '#fff2', paddingVertical: 5, paddingHorizontal: 15, borderRadius: 10 }}>inscription</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={{ flex: 1, justifyContent: 'center', alignItems: 'center', }}
                    onPress={() => navigation.navigate( 'Login' )}
                >
                    <Text style={{ color: '#a018db', backgroundColor: '#fff2', paddingVertical: 5, paddingHorizontal: 15, borderRadius: 10 }}>connexion</Text>
                </TouchableOpacity>

            </View>

        </View>
    )

}


const styles = StyleSheet.create({

    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#000'
    },
    
});


export default HomeScreen;