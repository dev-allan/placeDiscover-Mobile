import React, { useState, useEffect, Component } from 'react';
import { StyleSheet, SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList } from 'react-native';
import Geolocation from '@react-native-community/geolocation';
import Slider from '@react-native-community/slider';


const LocalizerScreen = ( props ) => {


    const [ search, setSearch ] = useState('Amiens') // recherche par ville
    const [ position, setPosition ] = useState([]); // coordonnées geo lat, lon
    const [ radius, setRadius ] = useState('500'); // périmètre de recherche
    const [ aroundData, setAroundData ] = useState('500'); // résulta recherche sur yelp


	const getPosition = () => { // obtient données de géoloc en fonction d'une adresse

        console.log('..getting data..')

		let key = 'authKey=RESTGP20210628162047598809937651'; // key forunit par michelin
		let basic = 'https://secure-apir.viamichelin.com/apir/1/geocode4f.json?'
		let response = 'geoData' // nom de la réponse
		let country = 'FRA'
		let city = search.toString()
		let zip = '80080'
		let address = ' 15 rue voltaire' // !! remplacer espace par %20 !! //
		let nb = '1' // nombre de résultats

		let url = `${basic}callback=${response}&country=${country}&city=${city}&zip=${zip}&address=${address}&${key}`;
		
		try {
			
			fetch(url)
			.then(res => res.text())
			.then(data => {
				data = data.replace((response + '('), '').replace(')', '')
				data = JSON.parse(data)
				console.log(data.locationList[0].location.coords)
				setPosition(data.locationList[0].location.coords)	
			})

		} catch (err) {
			console.error("Erreur de connexion à MICHELIN API..", err.message);
		}
	}
    

    const getGeoPosition = () => {
        
        try {

            Geolocation.getCurrentPosition(data => {
                const newPosition = { lat: data.coords.latitude, lon: data.coords.longitude }
                console.log(newPosition)
                setPosition(newPosition)
            });

        } catch (err) {
			console.error("Erreur de localisation..", err.message);
		}
        
    }


    const getAroundData = async () => {

		let id = '7l34sAxh_Oy3UicYnDFqhw'
		let key = 'RK9BvdqB4pat9WubUNEXmnAq8w9tTbHEQspC1G4bmymdl5WoiFcYYDjBKncJQev2wYFQNVbVXLFrINhkYQJ9CwZ2OQ-DGrIms0Z_hjijZ0Fapt7ZdZYKJmxXZZ3ZYHYx';
        let location = 'Amiens'
        let radius = '2000' // distance autour en mètre
        let limit = '20' // nombre max de résultats

        // ajouter term ou categories pour affiner recherche depuis les préference user
		let url = `https://api.yelp.com/v3/businesses/search?client_id=${id}&location=${location}&radius=${radius}&limit=${limit}`;
		
		try {
			
			await fetch(url, {
				method: "GET", //ou POST, PUT, DELETE, etc.
				headers: {
					'Authorization': `Bearer ${key}`,
				}
			})
            .then(res => res.json())
			.then(data => {
				console.log('around data', data)
				setAroundData(data);
			})

		} catch (err) {
			console.error("Failed to connect at YELP..", err.message);
		}
	}


    useEffect(() => {

		console.log('MAJ POSITION')

	}, [radius]);



    return (

        position.length == 0 ? 

        <View style={styles.container}>

            <View style={{ flex: 1, width: '90%', justifyContent: 'center', alignItems: 'center', }}>
                <Text style={{ color: '#ccc', }}>{ position.length != 0 ? position.toString() : 'Carte à afficher'}</Text>
            </View>

            <View style={{ flex: 1, width: '90%', justifyContent: 'center', alignItems: 'center', borderColor: '#a018db', borderWidth: 1, paddingHorizontal: 8, paddingVertical: 20}}>

                <TextInput
                    style={{ width: '80%', backgroundColor: '#fff1', color: '#fff', borderRadius: 10, paddingLeft: 10, marginBottom: 10}}
                    onChangeText={(search) => setSearch(search)}
                    value={search}
                    onSubmitEditing={() => getPosition()}
                    placeholder="recherche.."
                    placeholderTextColor='#ccc'
                />

                <Text style={{ color: '#a018db', marginBottom: 10 }}>OU</Text>

                <TouchableOpacity
                    style={{ flexDirection: 'row'}}
                    onPress={() => getGeoPosition()}
                >
                    {/* icon à ajouter */}
                    <Text style={{ width: '80%', textAlign: 'center', paddingVertical: 10, backgroundColor: '#a018db', color: '#fff', borderRadius: 20}}>Me localiser</Text>
                </TouchableOpacity>
            </View>

        </View>

        :

        <View style={styles.container}>

            <View style={{ flex: 1, width: '90%', justifyContent: 'center', alignItems: 'center', }}>
                <Text style={{ color: '#ccc', }}>{ position.length != 0 ? position.toString() : 'Carte à afficher'}</Text>
            </View>

            <View style={{ flex: 1, width: '90%', justifyContent: 'center', alignItems: 'center', borderColor: '#a018db', borderWidth: 1, paddingHorizontal: 8, paddingVertical: 20}}>

                <View style={{ flexDirection: 'row', width: '90%', justifyContent: 'space-around', marginBottom: 20}}>
                    <TouchableOpacity
                        style={{ justifyContent: 'center', alignItems: 'center', }}
                        onPress={() => getAroundData()}
                    >
                        <Text style={{ color: '#a018db', backgroundColor: '#000', borderColor: '#a018db', borderWidth: 1, paddingVertical: 5, paddingHorizontal: 15, borderRadius: 10 }}>maintenant !</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={{ justifyContent: 'center', alignItems: 'center', }}
                        onPress={() => getAroundData()}
                    >
                        <Text style={{ color: '#fff', backgroundColor: '#a018db', paddingVertical: 5, paddingHorizontal: 15, borderRadius: 10 }}>ce soir !</Text>
                    </TouchableOpacity>
                </View>

                { parseInt(radius) <= 2000 ?
                    <Text style={{ color: 'white'}}>{radius + 'm '}autour de moi</Text>
                :
                    <Text style={{ color: 'white'}}>{(parseInt(radius) / 1000) + 'km '}autour de moi</Text>
                }

                <Slider
                    style={{width: '100%', height: 40}}
                    minimumValue={500}
                    maximumValue={2000}
                    step={100}
                    minimumTrackTintColor="#fff3"
                    maximumTrackTintColor="#fffc"
                    thumbTintColor="#a018db"
                    onValueChange={(value) => setRadius(Math.round(value))}
                />
    
            </View>

        </View>


  
    )
}


const styles = StyleSheet.create({

    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#000',
    },
    
});


export default LocalizerScreen;