import React,  { useState, useEffect } from 'react';
import {StyleSheet, StatusBar } from 'react-native';


// splash screen //
import Waiter from './src/components/Waiter';

// navigation //
import { NavigationContainer } from '@react-navigation/native';
import MainStackNavigator from './src/navigations/MainStackNavigator'

// redux //
import {Provider} from 'react-redux';
import store from './src/stores/store';

// database //
import { getUserTable, getPreferenceTable } from './src/database/RealmDB';
import { objectId } from 'bson'; // génère l'objectId de la table


const App = () => {


    return (

		<Provider store={store}>

			<NavigationContainer>
				<StatusBar backgroundColor="#033245"  hidden={true}/>
				<MainStackNavigator />
			</NavigationContainer>

		</Provider>

    );
};


export default App;
