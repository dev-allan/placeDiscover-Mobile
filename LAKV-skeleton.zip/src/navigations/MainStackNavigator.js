import React, { useState} from 'react'
import { createStackNavigator } from '@react-navigation/stack'

// custom header and screens //
import HeaderNavigator from './HeaderNavigator'

import HomeScreen from '../screens/HomeScreen'
import LoginScreen from '../screens/LoginScreen'
import RegisterScreen from '../screens/RegisterScreen'
import RegisterScreen2 from '../screens/RegisterScreen2'

// attente tabanv...
import LocalizerScreen from '../screens/LocalizerScreen'


const Stack = createStackNavigator();


const MainStackNavigator = ( props ) => {

    
    return (
        
        <Stack.Navigator
            initialRouteName='Home'
        >

            <Stack.Screen
                name="Home"
                options={{ 
                    title: 'Accueil',
                    header: (props) => <HeaderNavigator {...props}  />,
                }}
            >
                {props => <HomeScreen {...props} />}
            </Stack.Screen>

            <Stack.Screen
                name="Login"
                options={{ 
                    title: 'Connexion',
                    header: (props) => <HeaderNavigator {...props}  />,
                }}
            >
                {props => <LoginScreen {...props} />}
            </Stack.Screen>

            <Stack.Screen
                name="Register"
                options={{ 
                    title: 'Inscription',
                    header: (props) => <HeaderNavigator {...props}  />,
                }}
            >
                {props => <RegisterScreen {...props} />}
            </Stack.Screen>

            <Stack.Screen
                name="Register2"
                options={{ 
                    title: 'Inscription2',
                    header: (props) => <HeaderNavigator {...props}  />,
                }}
            >
                {props => <RegisterScreen2 {...props} />}
            </Stack.Screen>

            <Stack.Screen
                name="Localizer"
                options={{ 
                    title: 'Localiser',
                    header: (props) => <HeaderNavigator {...props}  />,
                }}
            >
                {props => <LocalizerScreen {...props} />}
            </Stack.Screen>
        
        </Stack.Navigator>

    );
};

export default MainStackNavigator;
