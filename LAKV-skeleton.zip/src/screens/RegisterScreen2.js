import React from 'react';
import { StyleSheet, SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList } from 'react-native';


const RegisterScreen2 = ( props ) => {


    return (

        <Text style={{ color: '#a018db', }} >RegisterScreen2</Text>
    )

}


const styles = StyleSheet.create({

    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#000',
    },
    
});


export default RegisterScreen2;