import React, { useState, useEffect } from 'react';
import { StyleSheet, SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList } from 'react-native';


const LocalizerScreen = ( props ) => {


    const [ search, setSearch ] = useState('')
    const [ geoData, setGeoData ] = useState([]);


	const getGeoData = () => { // obtient données de géoloc en fonction d'une adresse

        console.log('..getting data..')

		let key = 'authKey=RESTGP20210628162047598809937651'; // key forunit par michelin
		let basic = 'https://secure-apir.viamichelin.com/apir/1/geocode4f.json?'
		let response = 'geoData' // nom de la réponse
		let country = 'FRA'
		let city = search.toString()
		let zip = '80080'
		let address = ' 15 rue voltaire' // !! remplacer espace par %20 !! //
		let nb = '1' // nombre de résultats

		let url = `${basic}callback=${response}&country=${country}&city=${city}&zip=${zip}&address=${address}&${key}`;
		

		try {
			
			fetch(url)
			.then(res => res.text())
			.then(data => {
				data = data.replace((response + '('), '').replace(')', '')
				data = JSON.parse(data)
				console.log(data.locationList[0].location.coords)
				setGeoData(data.locationList[0].location.coords)	
			})

		} catch (err) {
			console.error("Erreur de connexion à MICHELIN API..", err.message);
		}
	}
    

    const getAutoGeoData = () => {
        alert('localise moi !!!')
    }

    return (

        <View style={styles.container}>

            <Text style={{ color: '#a018db', }}>LocalizerScreen</Text>

            <View style={{ width: '90%', justifyContent: 'center', alignItems: 'center', borderColor: '#a018db', borderWidth: 1, paddingHorizontal: 8, paddingVertical: 20}}>

                <TextInput
                    style={{ width: '80%', backgroundColor: '#fff1', color: '#fff', borderRadius: 10, paddingLeft: 10, marginBottom: 10}}
                    onChangeText={(search) => setSearch(search)}
                    value={search}
                    onSubmitEditing={() => getGeoData()}
                    placeholder="recherche.."
                    placeholderTextColor='#ccc'
                />

                <Text style={{ color: '#a018db', marginBottom: 10 }}>OU</Text>

                <TouchableOpacity
                    style={{ flexDirection: 'row'}}
                    onPress={() => getAutoGeoData()}
                >
                    {/* icon à ajouter */}
                    <Text style={{ width: '80%', textAlign: 'center', paddingVertical: 10, backgroundColor: '#a018db', color: '#fff', borderRadius: 20}}>Me localiser</Text>
                </TouchableOpacity>
            </View>

            {/* <Text style={{ color: '#a018db', }}>Votre recherche: {search}</Text> */}

        </View>
            
    )

}


const styles = StyleSheet.create({

    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'space-around',
        backgroundColor: '#000',
    },
    
});


export default LocalizerScreen;